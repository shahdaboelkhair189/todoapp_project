import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:todoapp_project/appcolors.dart';
import 'package:flutter/src/widgets/container.dart';

class SettingsTab extends StatelessWidget {
  const SettingsTab({super.key});

  @override
  Widget build(BuildContext context) {
    var height=MediaQuery.of(context).size.height;
    var width=MediaQuery.of(context).size.width;
    return  Container(
        margin: EdgeInsets.all(15),
        child:Column(
          crossAxisAlignment:CrossAxisAlignment.start,
          children: [
            Text('Language',
              style:Theme.of(context).textTheme.bodyMedium,),
            SizedBox(height: height*0.1),
            Container(
                padding:EdgeInsets.all(8),
                decoration:BoxDecoration(
                color:Appcolors.whiteColor,

                    borderRadius:BorderRadius.circular(15),
                    border: Border.all(
                        color: Appcolors.primaryColor,
                        width:2
                    )


                ),
                child:Row(
                  mainAxisAlignment:MainAxisAlignment.spaceBetween ,
                  children:[
                    Text('English',
                      style:Theme.of(context).textTheme.bodyMedium,),
                    Icon(Icons.arrow_drop_down)

                  ],
                )


            )


          ],
        )
    );
  }
}