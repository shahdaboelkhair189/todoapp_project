import 'package:flutter/widgets.dart';

import '../firebase_utils.dart';
import '../model/task.dart';

class ListProvider extends ChangeNotifier{
  List<Task> tasksList=[];
  void getAllTaksFromFireStore()async{
    var querySnapshot= await FirebaseUtils.getTasksCollection().get();
    /// list<task>  => list<querydocumentSnapshot<task>>
    tasksList=querySnapshot.docs.map((doc){/// bt7wl list mn no3 le list mn no3 tany
      return doc.data();
    }).toList();

    notifyListeners();
  }

}