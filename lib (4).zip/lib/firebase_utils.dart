import 'package:cloud_firestore/cloud_firestore.dart';

import 'model/task.dart';

class FirebaseUtils {

static CollectionReference<Task> getTasksCollection(){ // kol ma 23oz 2geb el collection 2nady 3la function gettaskcolle
  return FirebaseFirestore.instance.collection(Task.collectionName)
      .withConverter<Task>(// bt5ly el fire base 3rfa no3 el 7aga ely btst5dmha ,keda bn5zn el task
      fromFirestore: ((snapshot,options) => Task.fromFireStore (snapshot.data()!) ),//data mwgoda gowa firebase fana 34an 2wslha lazm 2wsl lel document ya3ny Task gowah doc gowah data
  toFirestore:(task,options)=> task.toFireStore()
  );

}
  static Future<void> addTaskToFireStore(Task task){
var taskCollection=getTasksCollection();// lw 27tagt 2geb collection ,collection gowah document
var taskDocRef=taskCollection.doc(); //keda b3ml create le doc leeh id
task.id=taskDocRef.id; //el auto id elly et3ml fe firebase
return taskDocRef.set(task);


/// keda 3mlna collec w 3mlna doc w GBNA id BTA3 DOC 7tetO FE ID BTA3 taskaya w 5znto fe fire bSE
  }
}