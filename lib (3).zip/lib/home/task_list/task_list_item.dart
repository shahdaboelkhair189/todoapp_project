

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:todoapp_project/appcolors.dart';

class TaskListItem extends StatelessWidget {
  const TaskListItem({super.key});

  @override
  Widget build(BuildContext context) {
    
    return  Container(
      margin: EdgeInsets.all(12),
      child: Slidable(


        // The start action pane is the one at the left or the top side.
          startActionPane: ActionPane(
            extentRatio: 0.25,
            motion: const DrawerMotion(),


            children: [
              SlidableAction(
borderRadius: BorderRadius.circular(15),
                onPressed: (context){
                  ///delete task
                },
                backgroundColor: Appcolors.redColor,
                foregroundColor: Appcolors.whiteColor,
                icon: Icons.delete,
                label: 'Delete',
              ),
            ],
          ),

          // The end action pane is the one at the right
      child:Container(
          padding: EdgeInsets.all(12),

          decoration: BoxDecoration(
          color: Appcolors.whiteColor,
          borderRadius: BorderRadius.circular(25)

        ),

child: Row(
  mainAxisAlignment: MainAxisAlignment.spaceBetween,
  children: [
   Container(
       margin: EdgeInsets.all(15),
       height: MediaQuery.of(context).size.height*0.1,//bya5od nfs size fe 2y mobile
       width:4,
       color: Appcolors.primaryColor,




   ),
      Expanded(child: Column(
crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [

Text('Title',
style:  Theme.of(context).textTheme.bodyMedium?.copyWith(
  color:Appcolors.primaryColor
)),
          Text('Desc',style:  Theme.of(context).textTheme.bodyMedium),


        ],

      )),
      Container(
        padding: EdgeInsets.symmetric(horizontal: 17),
        decoration: BoxDecoration(

          borderRadius: BorderRadius.circular(15),
          color: Appcolors.primaryColor

        ),
        child: IconButton(onPressed: (){},icon: Icon(Icons.check,size: 30,color: Appcolors.whiteColor,),),

      )
  ],



)
      ),
      ),
    );
  }
}
