

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
class AddTaskBottomSheet extends StatelessWidget {
  String title='';
String description  ='';
var formKey=GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),


      color: Colors.white,
      child: SingleChildScrollView(
        child: Column(
          children:[


                  Text(AppLocalizations.of(context)!.add_new_task ,
                      style:Theme.of(context).textTheme.bodyMedium),
        Form(
          key:formKey ,//refrence 3la 2y 7aga gowa form

          child:Column(

        crossAxisAlignment:CrossAxisAlignment.stretch,
            children:[// 34an 2st5dm text form field lazm 27oto gowa form
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              onChanged: (text){
                title=text;
              },

  validator:(text){
  if(text==null || text.isEmpty){
  return  'please enter task title';//invalid
  }
  return null; //valid
  },





  decoration: InputDecoration(
                  labelText: 'Enter task title'
              ),

            ),
          ),//7aga 7yd5lha user

          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              onChanged: (text){// save le text el user
                description=text;
              },
              validator:(text){
                if(text==null || text.isEmpty){
                  return  'please enter task description';//invalid
                }
                return null; //valid
              },


              decoration: InputDecoration(
                  labelText: 'Enter task description'
              ),
              maxLines:4 ,

            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(AppLocalizations.of(context)!.select_date,
                style:Theme.of(context).textTheme.bodyMedium),
          ),


            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text('7/8/2024',
                  textAlign:TextAlign.center,
                  style:Theme.of(context).textTheme.bodyMedium),

            ),
              ElevatedButton(onPressed:() {
              addTask();

              }, child:Text(AppLocalizations.of(context)!.add ,
                  style:Theme.of(context).textTheme.bodyMedium),
              ),
     ],),),
          ],
        ),
      ),





    );

  }
void addTask(){/// method 7t3dyy 3la validtor for loop
    if(formKey.currentState?.validate()==true){

    }
}
}